package com.example.jsonget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
