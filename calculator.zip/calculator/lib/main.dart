import 'package:flutter/material.dart';

void main(List<String> args) {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  //const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text("calculator Application"),
      ),
      body: Home(),
    ),
    );
  }
}

class Home extends StatefulWidget {
  //const Home({Key? key}) : super(key: key);


  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController quantity = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController result = TextEditingController();

@override
  void initState() {
    // TODO: implement initState
    super.initState();
    result.text = "Buy X apples.Because each apple cost 100000 THB,You have to pay X THB";
  }
  @override
  Widget build(BuildContext context) {
    //return Container();
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Center(
        child: Column(
          children: [
            Image.asset("assets/sad.png", width: 200,),
            Text("Calculate Program",style: TextStyle(fontFamily: "Prompt-Thin"),),
            TextField(
              controller:quantity,
              decoration: InputDecoration(
                labelText: "Bearbrick quality",border: OutlineInputBorder()
              )
            ),
            Text("Bearbrick price",style: TextStyle(fontFamily: "Prompt-Thin"),),
            TextField(
              controller: price,
              decoration: InputDecoration(
                labelText: "Bearbrick price",border: OutlineInputBorder()
              )
            ),
            SizedBox(height: 20,),
            ElevatedButton(
              onPressed: () {
                var cal = double.parse(quantity.text)*double.parse(price.text);
                print("Bearbrick quality: ${quantity.text} Total : ${cal} THB");
                setState(() {
                  result.text = "Buy ${quantity.text} bearbrick.Because each bearbrick cost ${price.text} THB,You have to pay ${cal} THB";
                });
              },
              child: Text("Calculate"),
              style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Color(0xffb74093)), padding: MaterialStateProperty.all(EdgeInsets.fromLTRB(50, 20, 50, 20)), textStyle: MaterialStateProperty.all(TextStyle(fontSize: 30)))
            ),
            // Text("Buy 5 apples.Because each apple cost 10 THB,You have to pay 50 THB"),
            Text(result.text),
          ],
        ),
      ),
    );
  }
}