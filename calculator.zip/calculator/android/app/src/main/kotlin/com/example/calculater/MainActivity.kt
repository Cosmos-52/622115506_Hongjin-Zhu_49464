package com.example.calculater

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
